package com.kgl.assistantia;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class MainActivity extends Activity {
    EditText email,password,message; TextView output;
    // Replace with your HTTPS backend after deployment.
    final String BASE_URL="https://YOUR-DOMAIN.example";

    public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        email=findViewById(R.id.email); password=findViewById(R.id.password);
        message=findViewById(R.id.message); output=findViewById(R.id.output);
        findViewById(R.id.login).setOnClickListener(v->post("/api/login",authBody()));
        findViewById(R.id.register).setOnClickListener(v->post("/api/register",authBody()));
        findViewById(R.id.demo).setOnClickListener(v->post("/api/activate-demo",new JSONObject()));
        findViewById(R.id.send).setOnClickListener(v->{JSONObject j=new JSONObject();try{j.put("message",message.getText().toString());}catch(Exception ignored){}post("/api/chat",j);});
    }
    JSONObject authBody(){JSONObject j=new JSONObject();try{j.put("email",email.getText().toString());j.put("password",password.getText().toString());}catch(Exception ignored){}return j;}
    void post(String path, JSONObject body){
        output.setText("Chargement...");
        new Thread(()->{
            try{
                HttpURLConnection c=(HttpURLConnection)new URL(BASE_URL+path).openConnection();
                c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json");
                c.getOutputStream().write(body.toString().getBytes(StandardCharsets.UTF_8));
                InputStream in=(c.getResponseCode()<400?c.getInputStream():c.getErrorStream());
                BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));
                StringBuilder s=new StringBuilder();String line;while((line=r.readLine())!=null)s.append(line);
                JSONObject x=new JSONObject(s.toString());
                runOnUiThread(()->output.setText(x.optString("reply",x.optString("error","OK"))));
            }catch(Exception e){runOnUiThread(()->output.setText("Erreur de connexion."));}
        }).start();
    }
}
