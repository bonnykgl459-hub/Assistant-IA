# Assistant IA — compte + abonnement mensuel

Cette archive contient :
- un backend Python Flask ;
- création/connexion de comptes ;
- base SQLite ;
- abonnement DEMO de 30 jours sans paiement ;
- connexion serveur -> API OpenAI ;
- application Android.

IMPORTANT POUR UN VRAI PAIEMENT :
Le code fourni ne collecte pas de numéros de carte et ne simule pas un paiement réel. Pour un service commercial, le paiement doit passer par un prestataire autorisé avec une page de paiement hébergée et un webhook serveur. Le statut d'abonnement doit être activé seulement après confirmation du paiement.

Le prix de 1 USD/mois est un prix de TON service, pas le prix d'un abonnement ChatGPT. L'API OpenAI est facturée séparément selon son usage. OpenAI indique actuellement que les achats de crédits API prépayés ont un minimum de 5 USD.

Pour mettre en production :
1. Déployer backend sur HTTPS.
2. Définir SECRET_KEY et OPENAI_API_KEY uniquement sur le serveur.
3. Créer un produit récurrent à 1 USD/mois chez un prestataire de paiement disponible dans ton pays.
4. Ajouter l'endpoint de création de checkout et le webhook signé du prestataire.
5. Ne jamais stocker les numéros de cartes.
6. Remplacer BASE_URL dans MainActivity.java.
7. Ajouter les mentions légales, politique de confidentialité, conditions de paiement et mécanisme d'annulation/remboursement adaptés à ton pays.

La fonction "Abonnement DEMO" ne débite aucune carte et sert uniquement à tester l'application.
