import os
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, jsonify, render_template, request, session, redirect
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "CHANGE_ME")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///assistant.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    subscription_active = db.Column(db.Boolean, default=False)
    subscription_expires = db.Column(db.DateTime, nullable=True)

def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

def api_login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            return jsonify({"error": "Connexion requise"}), 401
        return fn(*args, **kwargs)
    return wrapper

@app.get("/")
def home():
    return render_template("index.html", user=current_user())

@app.post("/api/register")
def register():
    data = request.get_json() or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    if not email or len(password) < 8:
        return jsonify({"error": "Email et mot de passe (8 caractères minimum) requis."}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({"error": "Ce compte existe déjà."}), 409
    u = User(email=email, password_hash=generate_password_hash(password))
    db.session.add(u); db.session.commit()
    session["user_id"] = u.id
    return jsonify({"ok": True})

@app.post("/api/login")
def login():
    data = request.get_json() or {}
    u = User.query.filter_by(email=(data.get("email") or "").strip().lower()).first()
    if not u or not check_password_hash(u.password_hash, data.get("password") or ""):
        return jsonify({"error": "Identifiants incorrects."}), 401
    session["user_id"] = u.id
    return jsonify({"ok": True})

@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})

@app.get("/api/me")
def me():
    u = current_user()
    if not u:
        return jsonify({"logged_in": False})
    return jsonify({
        "logged_in": True,
        "email": u.email,
        "subscription_active": bool(u.subscription_active and u.subscription_expires and u.subscription_expires > datetime.now(timezone.utc).replace(tzinfo=None)),
        "subscription_expires": u.subscription_expires.isoformat() if u.subscription_expires else None
    })

@app.post("/api/activate-demo")
@api_login_required
def activate_demo():
    # DEMO ONLY. This does not charge a card.
    u = current_user()
    from datetime import timedelta
    u.subscription_active = True
    u.subscription_expires = datetime.utcnow() + timedelta(days=30)
    db.session.commit()
    return jsonify({"ok": True, "demo": True})

@app.post("/api/chat")
@api_login_required
def chat():
    u = current_user()
    if not (u.subscription_active and u.subscription_expires and u.subscription_expires > datetime.utcnow()):
        return jsonify({"error": "Abonnement inactif."}), 402

    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        return jsonify({"error": "OPENAI_API_KEY non configurée sur le serveur."}), 500

    from openai import OpenAI
    data = request.get_json() or {}
    message = (data.get("message") or "").strip()
    if not message:
        return jsonify({"error": "Message vide."}), 400

    try:
        client = OpenAI(api_key=key)
        response = client.responses.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-5.6-luna"),
            input=message
        )
        return jsonify({"reply": response.output_text})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

# Production payment integration:
# Create a Stripe/other PSP subscription from a server-side endpoint,
# then activate subscription ONLY after the provider webhook confirms payment.
# Never accept or store raw card numbers in this Flask app.
#
# Environment variables you would add for a real deployment:
# PAYMENT_PROVIDER, PRICE_ID, WEBHOOK_SECRET, PUBLIC_BASE_URL
#
# The Android app should open the provider's hosted checkout page.
# A real $1 recurring product may be subject to provider fees, taxes,
# currency rules and minimum-charge rules.

with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
